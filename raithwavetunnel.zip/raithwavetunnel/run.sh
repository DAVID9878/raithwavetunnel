#!/bin/bash
set -e
set -x

GenCase_linux64 Case_Def.xml
DualSPHysics5.2 Run.xml
PartVTK_linux64
